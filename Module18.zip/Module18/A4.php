<?php

namespace App\Http\Livewire;

use App\Models\Post;
use Livewire\Component;
use App\Models\Category;

class Cats extends Component
{
    public $categories, $postsCount;

    public function mount(Category $id)
    {
        $this->categories = Category::all();
        $this->postsCount = Post::where('category_id', '=', $id)->count();
    }

    public function render()
    {
        return view('livewire.cats');
    }
}